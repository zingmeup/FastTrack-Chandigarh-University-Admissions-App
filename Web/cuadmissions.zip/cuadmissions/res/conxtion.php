<?php
$conx=mysqli_connect('mysql.hostinger.in', 'u764646568_2082', '9872344592', 'u764646568_cuadm');
if (!$conx) {
	echo "<h1>Connection failed 500</h1>";
}

?>