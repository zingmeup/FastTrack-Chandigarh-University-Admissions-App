<?php
// HTTP
define('HTTP_SERVER', 'http://www.vqure.com/admin/');
define('HTTP_CATALOG', 'http://www.vqure.com/');

// HTTPS
define('HTTPS_SERVER', 'http://www.vqure.com/admin/');
define('HTTPS_CATALOG', 'http://www.vqure.com/');

// DIR
define('DIR_APPLICATION', '/home/kwyumzrrvibn/public_html/admin/');
define('DIR_SYSTEM', '/home/kwyumzrrvibn/public_html/system/');
define('DIR_LANGUAGE', '/home/kwyumzrrvibn/public_html/admin/language/');
define('DIR_TEMPLATE', '/home/kwyumzrrvibn/public_html/admin/view/template/');
define('DIR_CONFIG', '/home/kwyumzrrvibn/public_html/system/config/');
define('DIR_IMAGE', '/home/kwyumzrrvibn/public_html/image/');
define('DIR_CACHE', '/home/kwyumzrrvibn/public_html/system/storage/cache/');
define('DIR_DOWNLOAD', '/home/kwyumzrrvibn/public_html/system/storage/download/');
define('DIR_LOGS', '/home/kwyumzrrvibn/public_html/system/storage/logs/');
define('DIR_MODIFICATION', '/home/kwyumzrrvibn/public_html/system/storage/modification/');
define('DIR_UPLOAD', '/home/kwyumzrrvibn/public_html/system/storage/upload/');
define('DIR_CATALOG', '/home/kwyumzrrvibn/public_html/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'vqure_admin');
define('DB_PASSWORD', 'MO%;w8x-0oBo');
define('DB_DATABASE', 'vqure');
define('DB_PORT', '3306');
define('DB_PREFIX', '');
